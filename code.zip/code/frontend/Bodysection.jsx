
import Translator from './Translation';

const BodySection = () => {
  return (
    <div className="w-full m-8 ">
      <Translator />
    </div>
  );
};

export default BodySection;
